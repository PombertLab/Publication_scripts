#!/usr/bin/perl

use strict;
use warnings;

while (my $input = shift @ARGV){
	open IN, "<$input";
	open OUT, ">$input.count";

	my %seen = ();

	while ( my $line = <IN> ) {
		chomp $line;
		if ($line =~ /^(\d{1,})\t(\S+)\t\S+\t\S+\t\S+\t\S+\t\S+\t\S+\t\S+\t\S+\t(\S+)/){
			my $id = $1;
			my $source = $2;
			my $evalue = $3;
			$seen{$id}++;
			print OUT "$id\t$seen{$id}\t$source\t$evalue\n";
		}
	}
}